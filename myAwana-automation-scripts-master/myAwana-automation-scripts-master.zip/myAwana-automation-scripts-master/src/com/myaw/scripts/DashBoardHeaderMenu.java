package com.myaw.scripts;

import org.openqa.selenium.By;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.myaw.base.BaseTest;

public class DashBoardHeaderMenu extends BaseTest {
	
	@Test
	public void dashboardHeaderMenu()
	{
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	/*	String backToAwana = driver.findElement(By.xpath("//*[@*='https://www.awana.org/']")).getText();
		if (backToAwana.equals("https://www.awana.org/"))
		{
			Reporter.log("Back To Awana", true);
		}
		
		String myAwanaHeader = driver.findElement(By.partialLinkText("My Awana")).getText();
		
		if(myAwanaHeader.equals("My Awana"))
		{
			Reporter.log("My Awana", true);
		}
		
		
		String awanaStore = driver.findElement(By.partialLinkText("Awana Store")).getText();
		
		if(myAwanaHeader.equals("Awana Store"))
		{
			Reporter.log("Awana Store", true);
		}
		
		
		String latestcatalogs = driver.findElement(By.partialLinkText("Latest catalogs")).getText();
		
		if(myAwanaHeader.equals("Latest catalogs"))
		{
			Reporter.log("Latest catalogs", true);
		}
		
		String help = driver.findElement(By.partialLinkText("Help")).getText();
		
		if(myAwanaHeader.equals("Help"))
		{
			Reporter.log("Help", true);
		}
		
		String livechat = driver.findElement(By.partialLinkText("live chat")).getText();
		
		if(myAwanaHeader.equals("live chat"))
		{
			Reporter.log("live chat", true);
		}
		
	*/
	}
	
	

}
